package DBcontroller;

import model.Document;
import model.Loan;
import model.User;

public final class DBmgr {

	public DBmgr() {
		// TODO Auto-generated constructor stub
	}
	public User getUser(String Userid)
	{
		return null;
	}
	public Document getDocument(char callist)
	{
		return null;
	}
	public boolean saveLoan(Loan l)
	{
		return true;
	}
	public boolean saveDocument(Document d)
	{
		return true;
	}

}
