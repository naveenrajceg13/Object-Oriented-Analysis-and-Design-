package controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DBcontroller.DBmgr;
import model.Document;
import model.Loan;
import model.User;

/**
 * Servlet implementation class checkoutGUI
 */
@WebServlet("/checkoutGUI")
public class checkoutGUI extends HttpServlet {
	DBmgr db;
	User u;
	
	checkoutGUI()
	{
		db=new DBmgr();
	}
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		u=db.getUser(request.getParameter("userid"));
		if(u!=null){
			process(request.getParameter("callist").toCharArray());
		}
		
	}
	public void process(char[] callist){
		
		Document d;
		Loan l;
		boolean avability;
		for(int i=0;i<callist.length;i++){
			d=db.getDocument(callist[i]);
			if(d!=null)
			{
				avability=d.isAvailable();
				if(avability){
					l=new Loan(u,d);
					db.saveLoan(l);
					d.setAvailable(false);
					db.saveDocument(d);
				}
			}
		}
	}

}
