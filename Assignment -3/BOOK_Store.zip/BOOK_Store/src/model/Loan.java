package model;

import java.util.Date;

public class Loan {

	User u;
	Document d;
	Date fromdate;
	Date duedate;
	public Loan(User u,Document d)
	{
		
	}
	
	
}
