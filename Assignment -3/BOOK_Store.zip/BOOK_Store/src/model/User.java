package model;

public class User {
	
	String userid;
	String name;
	String address;
	
	User()
	{
		
	}

}
