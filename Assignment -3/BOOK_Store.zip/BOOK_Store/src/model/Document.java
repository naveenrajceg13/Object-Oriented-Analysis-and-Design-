package model;

public class Document {

	String cn;
	boolean isavailable;
	
	public Document(){
		isavailable=true;
	}
	public boolean isAvailable()
	{
		return isavailable;
	}
	public void setAvailable(boolean availbility){
		
		isavailable=availbility;
	}
}
